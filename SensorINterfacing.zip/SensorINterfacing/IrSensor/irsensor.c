#include <mraa.h>
#include <inttypes.h>

#define LED_PIN      63      /**< The pin where the LED is connected */
#define IR_PIN      31       /**< Button is connected to this pin */


int main(void)
{
  mraa_gpio_context      ledPin;  /* Will be used to represnt the LED pin */
  mraa_gpio_context      irPin;  /* Will be used to represnt the button pin */

  uint32_t               status;   /* Used to toggle the LED */
  uint32_t               irState; /* Used to capture the state of the button */

  mraa_init();  
/* lib initialisation*/
  ledPin = mraa_gpio_init(LED_PIN);/*mapping*/
  irPin = mraa_gpio_init(IR_PIN);

  mraa_gpio_dir(ledPin, MRAA_GPIO_OUT);/*setting mode as output*/
  mraa_gpio_dir(irPin, MRAA_GPIO_IN);/*input*/

while(1)
{
  status = mraa_gpio_read(irPin);/* read and store in status*/
  printf("STATUS = %d..\n\n",status);
    if(status == 0)
    {
        mraa_gpio_write(ledPin, 1);    
        printf("LED ON \n");
    }
    else
    {
        printf("LED OFF \n");
        mraa_gpio_write(ledPin, 0); // active low 0 is on the led
    }
sleep(1);
}

return 0;
}
